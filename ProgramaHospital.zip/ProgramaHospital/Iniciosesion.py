# Base de datos simulada de pacientes
pacientes = {
    "p001": "Juan Pérez",
    "p002": "María Gómez",
    "p003": "Jose García"
}

# Base de datos simulada de especialidades
especialidades = [
    "Medicina General",
    "Pediatría",
    "Cardiología",
    "Dermatología",
    "Traumatología"
]

def programar_cita():
    print("Bienvenido al sistema de programación de citas médicas")
    
    # Seleccionar ID del paciente
    print("\nPacientes disponibles:")
    for id_paciente in pacientes:
        print(f"- {id_paciente}: {pacientes[id_paciente]}")
    
    id_paciente = input("\nIntroduce el ID del paciente: ")
    
    # Verificar si el ID del paciente es válido
    if id_paciente not in pacientes:
        print("ID de paciente no válido. Intenta de nuevo.")
        return
    
    # Ingresar fecha y hora de la cita
    fecha_hora = input("Introduce la fecha y hora de la cita (formato: YYYY-MM-DD HH:MM): ")

    # Seleccionar especialidad médica
    print("\nEspecialidades disponibles:")
    for i, especialidad in enumerate(especialidades, 1):
        print(f"{i}. {especialidad}")
    
    seleccion = int(input("Selecciona el número de la especialidad: "))
    
    # Verificar si la selección es válida
    if 1 <= seleccion <= len(especialidades):
        especialidad_seleccionada = especialidades[seleccion - 1]
    else:
        print("Selección no válida. Intenta de nuevo.")
        return
    
    # Mostrar confirmación de la cita
    print("\nCita programada con éxito!")
    print(f"Paciente: {pacientes[id_paciente]}")
    print(f"Fecha y hora de la cita: {fecha_hora}")
    print(f"Especialidad: {especialidad_seleccionada}")

# Ejecutar función de programación de cita
if __name__ == "__main__":
    programar_cita()
