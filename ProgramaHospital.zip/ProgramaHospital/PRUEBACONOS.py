import os
import webbrowser
import getpass
from datetime import datetime
from collections import Counter
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog

# Base de datos simulada de usuarios con periodos de vacaciones
usuarios = {}

# Ruta de los archivos de log y usuarios
directorio_log = '/home/pablogj/Descargas/'
ruta_log = os.path.join(directorio_log, 'registro_sesion.log')
ruta_usuarios = os.path.join(directorio_log, 'usuarios.txt')
ruta_informe = os.path.join(directorio_log, 'informe_actividades.txt')

# Verificar si el directorio de logs existe, si no, lo crea
if not os.path.exists(directorio_log):
    os.makedirs(directorio_log)

# Cargar usuarios adicionales desde el archivo y combinarlos con la base simulada
def cargar_usuarios():
    if os.path.exists(ruta_usuarios):
        with open(ruta_usuarios, 'r') as f:
            for linea in f:
                if ',' in linea:
                    usuario, contraseña = linea.strip().split(',', 1)
                    usuarios[usuario] = {"contraseña": contraseña, "vacaciones": None}
                else:
                    print(f"Línea mal formada ignorada: {linea.strip()}")

# Guardar nuevo usuario en el archivo
def guardar_usuario(nuevo_usuario, nueva_contraseña):
    with open(ruta_usuarios, 'a') as f:
        f.write(f"{nuevo_usuario},{nueva_contraseña}\n")

# Función para registrar actividad
def registrar_actividad(actividad):
    try:
        with open(ruta_log, 'a') as f:
            f.write(f"{datetime.now()}: {actividad}\n")
    except PermissionError:
        print(f"Error: No se puede escribir en el archivo de log: {ruta_log}. Verifica los permisos.")

# Función para iniciar sesión
def iniciar_sesion(id_usuario, contraseña):
    if id_usuario in usuarios and usuarios[id_usuario]["contraseña"] == contraseña:
        registrar_actividad(f"Acceso autorizado para usuario: {id_usuario}")
        return True
    else:
        registrar_actividad(f"Intento fallido de inicio de sesión para usuario: {id_usuario}")
        return False

# Función para cambiar la contraseña
def modificar_contraseña(id_usuario, nueva_contraseña):
    if id_usuario in usuarios:
        usuarios[id_usuario]["contraseña"] = nueva_contraseña
        guardar_usuario(id_usuario, nueva_contraseña)
        registrar_actividad(f"Contraseña modificada para usuario: {id_usuario}")
        return True
    else:
        return False

# Función para asignar vacaciones
def asignar_vacaciones(id_usuario, periodo_vacaciones):
    if id_usuario in usuarios:
        usuarios[id_usuario]["vacaciones"] = periodo_vacaciones
        registrar_actividad(f"Vacaciones asignadas para usuario: {id_usuario} desde {periodo_vacaciones}")
        return True
    else:
        return False

# Función para abrir aplicaciones o URLs
def abrir_aplicacion_o_url(nombre_o_ruta):
    if nombre_o_ruta.startswith("http"):  # Si es una URL
        webbrowser.open(nombre_o_ruta)
        registrar_actividad(f"Apertura de URL: {nombre_o_ruta}")
    else:  # Si es una aplicación instalada
        try:
            os.system(nombre_o_ruta)
            registrar_actividad(f"Apertura de aplicación: {nombre_o_ruta}")
        except Exception as e:
            print(f"No se pudo abrir la aplicación '{nombre_o_ruta}'. Error: {e}")

# Función para agregar usuario
def agregar_usuario(nuevo_usuario, nueva_contraseña):
    if nuevo_usuario not in usuarios:
        usuarios[nuevo_usuario] = {"contraseña": nueva_contraseña, "vacaciones": None}
        guardar_usuario(nuevo_usuario, nueva_contraseña)
        registrar_actividad(f"Usuario {nuevo_usuario} agregado.")
        return True
    else:
        return False

# Función para listar usuarios
def listar_usuarios():
    usuarios_listados = []
    for usuario, datos in usuarios.items():
        vacaciones = datos["vacaciones"] if datos["vacaciones"] else "No asignadas"
        usuarios_listados.append(f"{usuario} (Vacaciones: {vacaciones})")
    return usuarios_listados

# Función para crear informe
def crear_informe():
    try:
        if os.path.exists(ruta_log):
            with open(ruta_log, 'r') as f:
                actividades = f.readlines()
            if actividades:
                with open(ruta_informe, 'w') as f_informe:
                    f_informe.write("Informe de Actividades\n")
                    f_informe.write("-" * 30 + "\n")  # Línea de separación
                    for actividad in actividades:
                        f_informe.write(actividad.strip() + "\n")
                    f_informe.write("-" * 30 + "\n")  # Línea de separación
                return f"Informe generado exitosamente en: {ruta_informe}"
            else:
                return "No hay actividades registradas."
        else:
            return "No se encontró el archivo de registro de actividades."
    except PermissionError:
        return f"Error: No se puede escribir en el archivo de informe: {ruta_informe}. Verifica los permisos."

# Función para identificar usuario más activo
def usuario_mas_activo():
    try:
        if os.path.exists(ruta_log):
            with open(ruta_log, 'r') as f:
                actividades = f.readlines()

            # Filtrar accesos autorizados y extraer los IDs de usuario
            usuarios_accesos = [linea.split(":")[-1].strip().split()[-1] for linea in actividades if "Acceso autorizado" in linea]

            # Contar accesos por usuario
            conteo_accesos = Counter(usuarios_accesos)

            if conteo_accesos:
                usuario_frecuente = conteo_accesos.most_common(1)[0]
                return f"El usuario con más accesos es {usuario_frecuente[0]} con {usuario_frecuente[1]} accesos."
            else:
                return "No se encontraron accesos en el registro."
        else:
            return "No se encontró el archivo de registro de actividades."
    except PermissionError:
        return f"Error: No se puede leer el archivo de log: {ruta_log}. Verifica los permisos."

# Función para eliminar usuario
def eliminar_usuario(id_usuario):
    if id_usuario in usuarios:
        del usuarios[id_usuario]
        with open(ruta_usuarios, 'w') as f:
            for usuario, datos in usuarios.items():
                f.write(f"{usuario},{datos['contraseña']}\n")
        registrar_actividad(f"Usuario {id_usuario} eliminado.")
        return True
    else:
        return False

# Interfaz gráfica con Tkinter
class Aplicacion(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gestión de Usuarios")
        self.geometry("500x400")

        # Menú
        self.menu_bar = tk.Menu(self)
        self.config(menu=self.menu_bar)

        # Menú de opciones
        self.menu_principal = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Opciones", menu=self.menu_principal)
        self.menu_principal.add_command(label="Iniciar sesión", command=self.iniciar_sesion_gui)
        self.menu_principal.add_command(label="Cambiar contraseña", command=self.cambiar_contraseña_gui)
        self.menu_principal.add_command(label="Asignar vacaciones", command=self.asignar_vacaciones_gui)
        self.menu_principal.add_command(label="Agregar usuario", command=self.agregar_usuario_gui)
        self.menu_principal.add_command(label="Listar usuarios", command=self.listar_usuarios_gui)
        self.menu_principal.add_command(label="Crear informe", command=self.crear_informe_gui)
        self.menu_principal.add_command(label="Usuario más activo", command=self.usuario_mas_activo_gui)
        self.menu_principal.add_command(label="Eliminar usuario", command=self.eliminar_usuario_gui)

        self.usuario_actual = None

    # Métodos de la interfaz gráfica
    def iniciar_sesion_gui(self):
        def iniciar():
            id_usuario = self.id_usuario_entry.get()
            contraseña = self.contraseña_entry.get()
            if iniciar_sesion(id_usuario, contraseña):
                messagebox.showinfo("Inicio de sesión", f"Acceso autorizado como {id_usuario}")
                self.usuario_actual = id_usuario
                login_window.destroy()
            else:
                messagebox.showerror("Error", "Credenciales incorrectas.")

        login_window = tk.Toplevel(self)
        login_window.title("Iniciar sesión")
        tk.Label(login_window, text="ID de Usuario:").pack()
        self.id_usuario_entry = tk.Entry(login_window)
        self.id_usuario_entry.pack()
        tk.Label(login_window, text="Contraseña:").pack()
        self.contraseña_entry = tk.Entry(login_window, show="*")
        self.contraseña_entry.pack()
        tk.Button(login_window, text="Iniciar sesión", command=iniciar).pack()

    def cambiar_contraseña_gui(self):
        if self.usuario_actual:
            nueva_contraseña = simpledialog.askstring("Cambio de contraseña", "Introduce la nueva contraseña:")
            if modificar_contraseña(self.usuario_actual, nueva_contraseña):
                messagebox.showinfo("Cambio de contraseña", "Contraseña modificada exitosamente.")
            else:
                messagebox.showerror("Error", "No se pudo cambiar la contraseña.")
        else:
            messagebox.showerror("Error", "Primero debes iniciar sesión.")

    def asignar_vacaciones_gui(self):
        if self.usuario_actual:
            vacaciones = simpledialog.askstring("Asignar vacaciones", "Introduce el periodo de vacaciones:")
            if asignar_vacaciones(self.usuario_actual, vacaciones):
                messagebox.showinfo("Asignar vacaciones", "Vacaciones asignadas exitosamente.")
            else:
                messagebox.showerror("Error", "No se pudieron asignar las vacaciones.")
        else:
            messagebox.showerror("Error", "Primero debes iniciar sesión.")

    def agregar_usuario_gui(self):
        nuevo_usuario = simpledialog.askstring("Agregar usuario", "Introduce el ID del nuevo usuario:")
        nueva_contraseña = simpledialog.askstring("Agregar usuario", "Introduce la contraseña del nuevo usuario:")
        if agregar_usuario(nuevo_usuario, nueva_contraseña):
            messagebox.showinfo("Agregar usuario", "Usuario agregado exitosamente.")
        else:
            messagebox.showerror("Error", "El usuario ya existe.")

    def listar_usuarios_gui(self):
        usuarios_listados = listar_usuarios()
        messagebox.showinfo("Lista de usuarios", "\n".join(usuarios_listados))

    def crear_informe_gui(self):
        resultado = crear_informe()
        messagebox.showinfo("Informe de Actividades", resultado)

    def usuario_mas_activo_gui(self):
        resultado = usuario_mas_activo()
        messagebox.showinfo("Usuario más activo", resultado)

    def eliminar_usuario_gui(self):
        id_usuario = simpledialog.askstring("Eliminar usuario", "Introduce el ID del usuario a eliminar:")
        if eliminar_usuario(id_usuario):
            messagebox.showinfo("Eliminar usuario", "Usuario eliminado exitosamente.")
        else:
            messagebox.showerror("Error", "No se pudo eliminar el usuario.")

# Cargar usuarios desde archivo al inicio
cargar_usuarios()

# Ejecutar la aplicación
app = Aplicacion()
app.mainloop()
