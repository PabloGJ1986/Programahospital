import pexpect

def su_user(user, password, command):
    print(f"Enviando la contraseña para el usuario: {user}")
    child = pexpect.spawn(f'su {user}', encoding='utf-8')

    try:
        child.expect('Contraseña:', timeout=10)
    except pexpect.EOF:
        print("No se pudo acceder al prompt.")
        return None
    except pexpect.TIMEOUT:
        print("Se alcanzó el tiempo de espera al esperar por 'Contraseña:'.")
        return None

    child.sendline(password)

    # Espera el prompt
    child.expect(r'[\$#>] ')  # Espera un prompt común

    # Ejecuta el comando deseado
    child.sendline(command)  # Envía el comando

    # Espera la salida del comando
    child.expect(r'[\$#>] ')  # Espera el prompt después de ejecutar el comando

    output = child.before.strip()  # Obtiene la salida antes del prompt
    return output  # Devuelve toda la salida

if __name__ == "__main__":
    user = 'medico'
    password = 'medico2024'  # Cambia esto a la contraseña real
    command = 'echo "Shell activo"'  # Comando a ejecutar

    output = su_user(user, password, command)
    print("Salida del comando:")
    print(output)

