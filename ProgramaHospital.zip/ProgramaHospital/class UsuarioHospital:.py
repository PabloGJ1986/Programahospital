class UsuarioHospital:
    def __init__(self):
        self.usuarios = {"doctor123": "password"}
        self.pacientes = {}
        self.historial_medico = {}
    
    # Acciones hospitalarias
    def inicio_sesion(self, usuario, contrasena):
        if self.usuarios.get(usuario) == contrasena:
            print("Inicio de sesión exitoso.")
            return True
        else:
            print("Credenciales incorrectas.")
            return False

    def registrar_paciente(self, id_paciente, nombre, fecha_nacimiento, genero, direccion, contacto):
        self.pacientes[id_paciente] = {
            "nombre": nombre,
            "fecha_nacimiento": fecha_nacimiento,
            "genero": genero,
            "direccion": direccion,
            "contacto": contacto
        }
        print(f"Paciente {nombre} registrado correctamente.")

    def registrar_diagnostico(self, id_paciente, fecha, sintomas, diagnostico, tratamiento):
        if id_paciente in self.pacientes:
            if id_paciente not in self.historial_medico:
                self.historial_medico[id_paciente] = []
            self.historial_medico[id_paciente].append({
                "fecha": fecha,
                "sintomas": sintomas,
                "diagnostico": diagnostico,
                "tratamiento": tratamiento
            })
            print(f"Diagnóstico registrado para el paciente {id_paciente}.")
        else:
            print("Paciente no encontrado.")

    def generar_informe_medico(self, id_paciente):
        if id_paciente in self.historial_medico:
            return self.historial_medico[id_paciente]
        else:
            return "No hay historial para este paciente."

    # Acciones de la vida real
    def comprar_desayuno(self, pedido, metodo_pago):
        print(f"Has comprado {pedido}. Pagado con {metodo_pago}.")

    def llenar_gasolina(self, litros, metodo_pago):
        print(f"Has llenado {litros} litros de gasolina. Pagado con {metodo_pago}.")

    def llamar_familiar(self, nombre_contacto):
        print(f"Llamando a {nombre_contacto}...")

    def enviar_correo(self, destinatario, asunto, cuerpo, adjunto):
        print(f"Correo enviado a {destinatario} con asunto '{asunto}' y adjunto '{adjunto}'.")

# Ejemplo de uso
sistema = UsuarioHospital()
sistema.inicio_sesion("doctor123", "password")
sistema.registrar_paciente("P001", "Juan Pérez", "1985-05-10", "Masculino", "Calle Falsa 123", "555-1234")
sistema.registrar_diagnostico("P001", "2024-10-18", "Fiebre, dolor de cabeza", "Gripe", "Paracetamol")
informe = sistema.generar_informe_medico("P001")
print(informe)

# Acciones de la vida real
sistema.comprar_desayuno("Café y croissant", "tarjeta")
sistema.llenar_gasolina(30, "efectivo")
sistema.llamar_familiar("María")
sistema.enviar_correo("maria@example.com", "Informe Médico", "Adjunto está el informe", "informe_paciente.pdf")
