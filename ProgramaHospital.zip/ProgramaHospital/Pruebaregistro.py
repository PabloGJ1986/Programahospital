import subprocess
import logging
import os

# Configurar el logging para registrar los eventos en un archivo de log
logging.basicConfig(filename=os.path.expanduser('~/registro_sesion.log'),
                    level=logging.INFO,
                    format='%(asctime)s - %(message)s')

def registrar_evento(evento):
    """Función para registrar eventos en el archivo de log"""
    logging.info(evento)

def sudo_user(command):
    """Función que ejecuta un comando como sudo"""
    print("Ejecutando comando con sudo...")
    
    try:
        # Cambiamos a ['sudo', '-S'] + command.split() para asegurarnos de que el comando se ejecute correctamente
        result = subprocess.run(['sudo', '-S'] + command.split(), 
                                input='tmedico2024\n', text=True, capture_output=True)
        
        output = result.stdout.strip()
        error = result.stderr.strip()
        
        if result.returncode == 0:
            registrar_evento(f"Salida del comando obtenida: {output}")
            return output
        else:
            registrar_evento(f"Error al ejecutar el comando: {error}")
            print(f"Error al ejecutar el comando: {error}")  # Imprimir el error
            return None
    except Exception as e:
        registrar_evento(f"Excepción al intentar ejecutar el comando: {str(e)}")
        print(f"Ocurrió una excepción: {e}")  # Imprimir la excepción
        return None

if __name__ == "__main__":
    command = 'echo "Shell activo"'  # Comando a ejecutar

    # Crear el archivo de registro para verificar que funciona
    with open(os.path.expanduser('~/registro_sesion.log'), 'w') as f:
        f.write("Este es un mensaje de prueba para verificar el registro.\n")

    # Registrar inicio de sesión
    registrar_evento("Inicio de sesión.")

    output = sudo_user(command)
    
    print("Salida del comando:")
    print(output if output is not None else "No se obtuvo salida del comando.")

    # Registrar cierre de sesión
    registrar_evento("Cierre de sesión.")
