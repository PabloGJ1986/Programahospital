import os

# Nombre del nuevo directorio
nombre_directorio = 'mi_directorio'

# Crear un nuevo directorio si no existe
if not os.path.exists(nombre_directorio):
    os.mkdir(nombre_directorio)
    print(f'Directorio "{nombre_directorio}" creado.')

# Cambiar al nuevo directorio
os.chdir(nombre_directorio)
print(f'Ahora estamos en: {os.getcwd()}')

# Crear algunos archivos dentro del nuevo directorio
for i in range(5):
    nombre_archivo = f'archivo_{i + 1}.txt'
    with open(nombre_archivo, 'w') as f:
        f.write(f'Este es el contenido del {nombre_archivo}\n')
    print(f'Archivo "{nombre_archivo}" creado.')

# Listar los archivos en el directorio actual
print('Archivos en el directorio actual:')
print(os.listdir())

# Volver al directorio original
os.chdir('..')
print(f'Volvimos a: {os.getcwd()}')

# Eliminar el directorio y todo su contenido
import shutil

shutil.rmtree(nombre_directorio)
print(f'Directorio "{nombre_directorio}" y su contenido han sido eliminados.')
