### Acciones de un usuario en un contexto hospitalario y su vida real:

#### 1. **Compra de desayuno en una cafetería**
- Usuario selecciona:
  - **Café** y/o **bocadillo**.
  - Paga con **tarjeta** o **efectivo**.
  - Recibe el pedido.

#### 2. **Inicio de sesión en el sistema hospitalario**
- El usuario ingresa su **ID de usuario** y **contraseña**.
- El sistema verifica las credenciales y autoriza el acceso.

#### 3. **Consulta del clima para el sábado**
- El usuario verifica el tiempo porque tiene planes de ir al campo.

#### 4. **Revisión de expedientes**
- El usuario revisa algunos expedientes importantes para enviarlos.

#### 5. **Búsqueda de historial médico de un paciente**
- El usuario busca en el sistema el historial médico de un paciente.

#### 6. **Registro de un nuevo paciente**
- Completar el formulario con los datos del paciente:
  - **Nombre completo**, **fecha de nacimiento**, **género**, **dirección**, **número de contacto**.

#### 7. **Verificación de correos electrónicos**
- El usuario se asegura de algunos correos importantes.

#### 8. **Programación de cita médica**
- Seleccionar:
  - **ID del paciente**, **fecha y hora de la cita**, **especialidad médica**.
  - Confirmar la cita.

#### 9. **Reunión en el hospital**
- El usuario regresa al hospital para asistir a una reunión programada.
  - **Hora de inicio de la reunión**: [Hora]
  - **Hora de finalización de la reunión**: [Hora]

#### 10. **Revisión de una nueva normativa para aplicar en el hospital**
- El usuario revisa un protocolo futuro para el hospital.

#### 11. **Programación de una cita para operación la semana próxima**
  - **Hora de inicio de la operación**: [Hora]
  - **Hora de finalización de la operación**: [Hora]

#### 12. **Cerrar la sesión de expedientes y apagar el ordenador**
- El usuario cierra su sesión de trabajo y apaga el ordenador.
  - **Hora de inicio de la sesión**: [Hora]
  - **Hora de finalización de la sesión**: [Hora]

#### 13. **Ir al parking para recoger el coche e ir al gimnasio**
  - **Hora de inicio al entrar en el parking**: [Hora]
  - **Hora de finalización al sacar el coche del parking**: [Hora]

#### 14. **Desayunar y dirigirse al hospital**
  - **Hora de inicio en el hospital**: [Hora]
  - **Hora de finalización**: [Hora]

#### 15. **Atender citas rutinarias con pacientes**
- Consultas y seguimientos de pacientes programados.

#### 16. **Revisión del calendario de citas para la semana siguiente**
- El usuario revisa las citas y gestiona cambios si es necesario.

#### 17. **Revisión de protocolos de seguridad hospitalaria**
- Asegurarse de que todos los procedimientos de seguridad estén actualizados.

#### 18. **Reunión con el departamento de finanzas**
  - **Hora de inicio de la sesión**: [Hora]
  - **Hora de finalización de la sesión**: [Hora]

#### 19. **Actualización del software del sistema hospitalario**
- Realizar la actualización de software para mejorar la funcionalidad del sistema.
  - **Actualización completada**: **Sí** / **No**

#### 20. **Verificación de la disponibilidad de camas en el hospital**
- **Hay camas disponibles SI/NO**

#### 21. **Control de acceso basado en roles para áreas restringidas**
- El sistema verifica las credenciales del personal y permite o deniega el acceso a áreas restringidas.
  - **Acceso permitido**: **Sí** / **No**
  - **Área restringida**: [Nombre del área]
#### 22. **Generación de informes de actividad diaria**
- El sistema genera automáticamente un informe detallado de todas las actividades realizadas por el personal.
  - **Hora de generación del informe**: [Hora]
  - **Formato del informe**: **PDF** / **CSV*

#### 23. **Envío de notificaciones sobre resultados de laboratorio**
- El sistema alerta automáticamente al médico responsable cuando se actualizan resultados de pruebas de laboratorio.
  - **Prueba de laboratorio**: [Tipo de prueba]
  - **Resultado disponible**: **Sí** / **No**
  #### 24. **Automatización de encuestas de satisfacción del paciente**
- El sistema envía encuestas de satisfacción a los pacientes tras sus citas o estancias en el hospital.
  - **Hora de envío de la encuesta**: [Hora]
  - **Respuesta recibida**: **Sí** / **No**
#### 25 **Verificación automática de seguros médicos**
- El sistema verifica automáticamente la cobertura de seguros médicos para los pacientes al registrarse.
  - **Seguro verificado**: **Sí** / **No**
  - **Cobertura confirmada**: **Sí** / **No**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
