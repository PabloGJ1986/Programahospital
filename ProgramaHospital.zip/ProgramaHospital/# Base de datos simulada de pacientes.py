# Base de datos simulada de usuarios
usuarios = {
    "admin": "admin123",
    "doctor": "doctor456",
    "enfermera": "enfermera789"
}

def iniciar_sesion():
    print("Bienvenido al sistema hospitalario")
    
    # Solicitar ID de usuario y contraseña
    id_usuario = input("Introduce tu ID de usuario: ")
    contraseña = input("Introduce tu contraseña: ")
    
    # Verificar credenciales
    if id_usuario in usuarios and usuarios[id_usuario] == contraseña:
        print("Acceso autorizado. Bienvenido, {}!".format(id_usuario))
    else:
        print("Credenciales incorrectas. Inténtalo de nuevo.")

# Ejecutar función de inicio de sesión
if __name__ == "__main__":
    iniciar_sesion()
